# 📖 Theology AI Lab v2.7

> **"내 컴퓨터에 신학 연구소를 차리다."**
> 
> Theology AI Lab은 **내가 가진 신학책을 마음껏 연구할 수 있는** 개인용 디지털 서재입니다.

---

## 🚀 빠른 설치 (Quick Install)

### ⚡ 1. AI 에이전트 이용 시 (권장)

**Antigravity, Gemini CLI, Claude Desktop** 등에서 아래 명령어를 복사 붙여넣기:

```
이 폴더에서 Theology AI Lab을 설치해줘.
1_INSTALL_MAC.command 스크립트를 실행해서 설치하면 돼.
```

> AI가 자동으로 가상환경 생성, 의존성 설치, 앱 실행까지 처리합니다.

---

### 📦 2. 수동 설치

#### 🅰️ Docker 이용 (환경 분리)
```bash
docker compose up -d
# 브라우저에서 http://localhost:8501 접속
```

#### 🅱️ Docker 없이 (Python 직접)
- 🍎 **Mac:** `1_INSTALL_MAC.command` 더블클릭
- 🪟 **Windows:** `1_INSTALL_WIN.bat` 더블클릭

*⚠️ Python 3.11 필요*

---

## 📚 빠른 사용 (Quick Usage)

### ⚡ 1. AI 에이전트 이용 시 (권장)

자연어로 AI에게 요청하세요:

| 작업 | 요청 예시 |
|------|----------|
| **서재 업데이트** | "inbox에 있는 PDF 인덱싱해줘" |
| **검색** | "칭의론에 대해 서재에서 찾아줘" |
| **DB 상태** | "현재 서재 통계 알려줘" |

---

### 🖥️ 2. 일반 이용 (Web GUI)

1. 앱 실행: `3_START_MAC.command` (Mac) 또는 `3_START_WIN.bat` (Win)
2. 브라우저에서 `http://localhost:8501` 접속
3. GUI에서:
   - **🔍 검색**: 키워드 입력 → AI 분석 → Obsidian 저장
   - **📤 파일 업로드**: PDF/TXT/EPUB 인덱싱
   - **📊 통계**: 서재 현황 확인

---

## ✨ v2.7 주요 기능

| 기능 | 설명 |
|------|------|
| 🖥️ **Web GUI** | Streamlit 기반 브라우저 인터페이스 |
| 📖 **EPUB 지원** | PDF, TXT, EPUB 인덱싱 가능 |
| 📦 **1GB 업로드** | 대용량 파일 지원 |
| 🔄 **업데이트 스크립트** | 데이터 유지하며 코드만 업데이트 |
| 🤖 **AI 분석** | 검색 결과 종합 리포트 생성 |
| 🌐 **다국어 검색** | 한글로 검색 → 독일어/러시아어 결과 |

---

## 📁 폴더 구조

```
Theology_AI_Lab/
├── 01_Library/          ← 📚 서재 (사용자 관리)
│   ├── inbox/           ← 새 파일 넣는 곳
│   └── archive/         ← 인덱싱된 데이터 (삭제 금지)
├── 02_Brain/            ← 🧠 벡터 DB (자동 관리)
└── 03_System/           ← ⚙️ 시스템 코드
```

---

## 🔄 업데이트

기존 데이터(서재, DB)를 유지하면서 코드만 업데이트:

1. 새 버전 zip을 폴더에 복사
2. `UPDATE_MAC.command` (Mac) 또는 `UPDATE_WIN.bat` (Win) 실행
3. 자동으로 백업 + 코드 교체 + 의존성 업데이트

---

## 🟣 Obsidian 연동

👉 [Obsidian 연동 가이드](docs/OBSIDIAN_INTEGRATION.md)

---

## ⚠️ 문제 해결

| 문제 | 해결 |
|------|------|
| "개발자 확인 불가" (Mac) | 파일 우클릭 → [열기] |
| Docker 시작 안 됨 | Docker Desktop 먼저 실행 |
| Python 버전 오류 | Python 3.11 설치 필요 |

---

> **☕️ 유익하셨나요?**  
> **Made by [Kerygma Press](https://www.kerygma.co.kr)**
