# 📖 Theology AI Lab v2.7 Premium: 사용자 매뉴얼 (User Guide)

> **"내 컴퓨터에 신학 연구소를 차리다."**
> Theology AI Lab은 인공지능(Antigravity/Claude Desktop)과 함께 **내가 가진 신학책을 마음껏 연구할 수 있는** 개인용 디지털 서재입니다.

---

## v2.1 새로운 기능 ✨

| 기능 | 설명 |
|------|------|
| **🤖 AI 분석** | 검색 결과를 AI가 종합 분석하여 리포트 생성 |
| **실시간 소스 관리** | 통계 페이지에서 소스 삭제 즉시 반영 |
| **인박스 자동 정리** | 처리 완료된 파일 자동 정리 |
| **Docker 원클릭 설치** | Python 환경 걱정 없이 Docker만으로 설치 |
| **OCR 자동화** | 이미지 PDF도 자동으로 텍스트 추출 |

---

## 0. 🛠️ 준비물 (Prerequisites)

### 필수
- **Docker Desktop** (무료)
  - 👉 [Docker 다운로드](https://www.docker.com/products/docker-desktop/)

### 권장
- **Antigravity** 또는 **VS Code** (Claude Desktop)
  - 👉 [Antigravity 다운로드](https://antigravity.google)

---

## 1. 🚀 설치 및 시작 (One-Click Installation)

### ⚡️ Docker 원클릭 설치 (권장)

1. **설치 스크립트 실행**
   - 🍎 **Mac:** `INSTALL_ONECLICK.command` 더블클릭
   - 🪟 **Windows:** `INSTALL_ONECLICK.bat` 더블클릭

2. **자동 수행 내용:**
   - Docker 실행 확인
   - 환경 설정 (.env 생성)
   - AI 컨테이너 빌드 (최초 5-10분 소요)

3. **"설치 완료" 메시지**가 나오면 끝!

---

### 📦 기존 방식 (Python 직접 설치)

Docker 없이 기존 방식으로 설치하려면:

1. 🍎 **Mac:** `1_INSTALL_MAC.command` 실행
2. 🪟 **Windows:** `1_INSTALL_WIN.bat` 실행

*⚠️ Python 3.11이 필요합니다.*

---

## 2. 📚 나만의 디지털 서재 구축 (Local Pipeline)

자료를 추가할 때도 복잡한 명령어를 입력할 필요가 없습니다.

1. **자료 넣기**: `01_Library/inbox` 폴더에 원하는 PDF 파일을 넣으세요.
   - ✅ 텍스트 PDF: 바로 처리됩니다
   - ✅ 이미지 PDF: **v2.0에서 OCR 자동 처리!** (Tesseract 내장)

2. **AI에게 요청**: Antigravity에서 이렇게 말하세요.
   > **"내 서재 업데이트해줘."**

   (AI가 알아서 OCR → 텍스트 추출 → 서재에 꽂고 → 읽을 준비를 마칩니다.)

---

## 3. 🤖 연구 수행 (Antigravity Integration)

이제 복잡한 검색법을 배울 필요가 없습니다. **"AI에게 그냥 물어보세요."**

### 예시 질문

- **내용이 궁금할 때 (의미 검색)**
  > "신학 DB에서 '칭의(Justification)'에 대한 내용을 찾아줘."

- **AI 분석이 필요할 때**
  > GUI 검색 후 🤖 AI 분석 버튼 클릭

- **DB 상태 확인**
  > "신학 DB 통계를 알려줘."

---

## 4. 📁 폴더 구조 안내

여러분이 관리해야 할 폴더는 딱 하나입니다.

- 📂 **01_Library**: 서재
  - 📥 `inbox`: 새 책을 넣는 곳 (작업 후 비워집니다)
  - 📚 `archive`: 정리된 책이 보관되는 곳 (지우지 마세요!)

- *나머지 `02_Brain`, `03_System` 폴더는 AI가 관리하는 정비실이므로 들어가지 않으셔도 됩니다.*

---

## 5. 🐳 Docker 관리 명령어

터미널에서 이 폴더로 이동 후 사용하세요:

```bash
# 상태 확인
docker compose ps

# 로그 보기
docker compose logs -f

# 중지
docker compose down

# 재시작
docker compose restart

# 재빌드 (업데이트 후)
docker compose build --no-cache
docker compose up -d
```

---

## 6. 🛠️ 서재 관리 (Library Management)

파일 목록을 확인하거나 정리하고 싶을 때도 **AI에게 시키세요.**

### 📋 목록 확인
> **"내 서재에 어떤 책들이 있어?"**
> (AI가 보관된 책 목록을 확인해서 알려줍니다.)

### 🔄 서재 정리 (Reset)
책을 처음부터 다시 정리하고 싶다면 이 순서대로 해주세요.

1. **초기화:** `02_Brain/vector_db` 폴더를 **삭제**합니다.
2. **재색인:** 원하는 파일을 `inbox`로 옮긴 뒤, **"내 서재 업데이트해줘"**라고 말하세요.

---

## 7. ⚠️ 문제 해결 (Troubleshooting)

### Q. Docker가 시작되지 않아요
**A.** Docker Desktop을 먼저 실행하세요. 시스템 트레이에 고래 아이콘이 보이면 정상입니다.

### Q. '개발자를 확인할 수 없다'며 실행이 안 돼요 (Mac)
**A.** 보안 경고입니다. 파일을 **마우스 우클릭 → [열기]** 선택하세요.

### Q. 빌드가 오래 걸려요
**A.** 최초 빌드 시 AI 모델 다운로드로 5-10분 소요됩니다. 이후에는 빠릅니다.

### Q. OCR이 작동하지 않아요
**A.** Docker 이미지에 Tesseract가 내장되어 있습니다. `docker compose logs`로 오류를 확인하세요.

---

## 8. 🔧 고급 설정

### 환경 변수 (.env)

```bash
# ChromaDB 경로
CHROMA_DB_DIR=./02_Brain/vector_db

# 라이브러리 경로
ARCHIVE_DIR=./01_Library/archive
INBOX_DIR=./01_Library/inbox

# OCR 설정
OCR_ENABLED=true
OCR_LANGUAGES=deu+eng+grc+heb+kor
```

### Claude Desktop 연동 (선택)

`~/.config/claude/settings.json`:
```json
{
  "mcpServers": {
    "theology-lab": {
      "command": "docker",
      "args": ["exec", "-i", "theology-ai-lab", "uv", "run", "python", "server.py"]
    }
  }
}
```

---

## 9. 🟣 Obsidian 연동 상세 가이드
Theology AI Lab과 옵시디언을 유기적으로 결합하여 '제2의 뇌'를 구축하는 상세 방법(Custom Frames, MCP 등)은 아래 가이드를 참고하세요.

👉 [Obsidian 연동 가이드 상세 보기](docs/OBSIDIAN_INTEGRATION.md)

---

> **☕️ Theology AI Lab이 유익하셨나요?**
> 책 한 권 구입으로 커피 한 잔을 선물해 주세요. 여러분의 연구를 응원합니다!
>
> **Made by [Kerygma Press](https://www.kerygma.co.kr)**
