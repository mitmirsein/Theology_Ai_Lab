# 📖 Theology AI Lab v2.7

> **"내 컴퓨터에 신학 연구소를 차리다."**

개인용 AI 기반 신학 연구 도구입니다. PDF, TXT, EPUB 파일을 인덱싱하고 의미 검색 및 AI 분석이 가능합니다.

---

## 📥 다운로드 및 설치

### 1. Zip 다운로드

👉 **[Kerygma_Theology_AI_Lab_v2.7.23_Clean.zip](Kerygma_Theology_AI_Lab_v2.7.23_Clean.zip)** (위 파일 클릭)

또는 [Releases 페이지](https://github.com/mitmirsein/Theology_Ai_Lab/releases)에서 최신 버전 다운로드

---

### 2. 설치

#### ⚡ AI 에이전트로 설치 (Antigravity, Gemini CLI 등)

zip 압축 해제 후 AI에게 요청:
```
이 폴더에서 1_INSTALL_MAC.command를 실행해서 설치해줘.
```

#### 🖱️ 수동 설치

1. **압축 해제** - 원하는 위치에 폴더 생성
2. **설치 스크립트 실행**
   - 🍎 **Mac:** `1_INSTALL_MAC.command` 더블클릭
   - 🪟 **Windows:** `1_INSTALL_WIN.bat` 더블클릭
3. **자동 설치** - Python 환경 + 의존성 + 앱 실행

---

## ✨ 주요 기능

| 기능 | 설명 |
|------|------|
| 🖥️ **Web GUI** | 브라우저 기반 인터페이스 |
| 📖 **다중 형식** | PDF, TXT, EPUB 지원 |
| 🌐 **다국어 검색** | 한글 → 독일어/영어/러시아어 |
| 🤖 **AI 분석** | 검색 결과 종합 리포트 (API 키 필요) |
| 🔄 **간편 업데이트** | 데이터 유지하며 코드만 업데이트 |

> **🔑 AI 분석 기능 사용 시**: `.env` 파일에 API 키 등록 필요  
> 지원: Gemini, OpenAI, Anthropic

---

## � Obsidian 연동

검색 결과를 Obsidian 노트로 바로 저장할 수 있습니다.

### 설정 방법
1. **Obsidian Vault 경로 설정** - GUI 설정 페이지에서 경로 입력
2. **검색 후 저장** - 🔍 검색 → 📝 Obsidian 저장 버튼

### 저장 형식
```markdown
---
source: TDNT
query: χάρις
date: 2026-01-01
---
# 검색 결과: χάρις
[AI 분석 내용 + 원문 청크]
```

*상세 가이드: 설치 후 `docs/OBSIDIAN_INTEGRATION.md` 참조*

---

> **Made by [Kerygma Press](https://www.kerygma.co.kr)**
