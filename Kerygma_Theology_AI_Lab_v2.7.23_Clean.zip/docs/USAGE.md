# Theology AI Lab v2.7 Premium - 사용 가이드

## 기본 사용법

### 1. 자료 추가하기

1. PDF 파일을 `01_Library/inbox/` 폴더에 넣습니다
2. Claude Desktop(Antigravity)에서 다음과 같이 말합니다:

> **"내 서재 업데이트해줘"**

3. AI가 자동으로 처리합니다:
   - 이미지 PDF → OCR 텍스트 추출
   - 텍스트 청킹 및 메타데이터 추출
   - 벡터 데이터베이스 인덱싱
   - 처리 완료된 파일 자동 정리 (inbox 비움)

---

### 2. 검색하기

Claude Desktop에서 자연어로 질문하세요:

| 질문 유형 | 예시 |
|----------|------|
| 개념 검색 | "칭의(Justification)에 대해 찾아줘" |
| 인물 검색 | "Luther의 은혜론에 대해 알려줘" |
| 사전 항목 | "Gnade 항목을 찾아줘" |
| 비교 검색 | "칭의와 성화의 차이점을 찾아줘" |
| AI 분석 | GUI에서 검색 후 🤖 버튼 클릭 |

### 검색 결과 형식

```
--- [출처 1: EKL I, p.234 – Gnade] ---
Gnade (lat. gratia, griech. charis) ist ein zentraler
Begriff der christlichen Theologie...

--- [출처 2: RGG IV, p.567 – Rechtfertigung] ---
Die Rechtfertigung des Sünders...
```

---

### 3. 서재 관리

| 명령 | 설명 |
|------|------|
| "내 서재에 어떤 책들이 있어?" | 보관된 문서 목록 확인 |
| "신학 DB 통계 알려줘" | 인덱싱된 문서 수 확인 |
| "내 서재 업데이트해줘" | 새 파일 처리 |

### 4. AI 분석 (GUI 전용)

GUI(http://localhost:8501)에서만 사용 가능한 AI 분석 기능:

1. 검색 수행
2. **🤖 AI 분석** 버튼 클릭
3. AI가 검색 결과를 종합 분석하여 리포트 생성
4. 리포트 다운로드 또는 Obsidian 저장 가능

**지원 AI 모델:**
- Anthropic Claude (claude-3-5-sonnet 등)
- OpenAI GPT (gpt-4o 등)
- Google Gemini (gemini-1.5-pro 등)

*설정 페이지에서 API 키 등록 필요*

---

## 지원 파일 형식

| 형식 | 처리 방식 |
|------|----------|
| 텍스트 PDF | 직접 텍스트 추출 |
| 이미지 PDF (스캔) | OCR 자동 처리 |
| TXT 파일 | 직접 처리 |

### OCR 지원 언어

- 독일어 (deu)
- 영어 (eng)
- 그리스어 (grc)
- 히브리어 (heb)
- 한국어 (kor)

---

## Claude Desktop 연동 설정

### Antigravity / Claude Desktop

설정 파일 위치:
- Mac: `~/.config/claude/settings.json`
- Windows: `%APPDATA%\Claude\settings.json`

```json
{
  "mcpServers": {
    "theology-lab": {
      "command": "docker",
      "args": ["exec", "-i", "theology-ai-lab", "uv", "run", "python", "server.py"]
    }
  }
}
```

### VS Code (Claude Code)

프로젝트의 `.vscode/settings.json` 또는 워크스페이스 설정에 추가.

---

## Docker 관리

### 상태 확인
```bash
docker compose ps
```

### 로그 보기
```bash
docker compose logs -f
```

### 서비스 중지
```bash
docker compose down
```

### 서비스 재시작
```bash
docker compose restart
```

### 업데이트 후 재빌드
```bash
docker compose build --no-cache
docker compose up -d
```

---

## 문제 해결

### Q. "Docker가 실행되지 않습니다"

**A.** Docker Desktop을 먼저 실행하세요.
- Mac: 상단 메뉴바에 고래 아이콘 확인
- Windows: 시스템 트레이에 고래 아이콘 확인

### Q. "확인되지 않은 개발자" 경고 (Mac)

**A.** 파일을 **마우스 우클릭 → 열기**로 실행하세요.

### Q. 검색 결과가 없습니다

**A.** 다음을 확인하세요:
1. `docker compose ps`로 컨테이너 실행 확인
2. "신학 DB 통계 알려줘"로 인덱싱 여부 확인
3. inbox에 파일을 넣고 "내 서재 업데이트해줘" 실행

### Q. OCR이 작동하지 않습니다

**A.** Docker 로그를 확인하세요:
```bash
docker compose logs | grep -i ocr
```

### Q. 서재를 초기화하고 싶습니다

**A.** 다음 순서로 진행:
1. `02_Brain/vector_db/` 폴더 삭제
2. 원하는 PDF를 `01_Library/inbox/`로 이동
3. "내 서재 업데이트해줘" 실행

---

## 고급 설정

### 환경 변수 (.env)

```bash
# ChromaDB 경로
CHROMA_DB_DIR=./02_Brain/vector_db

# 라이브러리 경로
ARCHIVE_DIR=./01_Library/archive
INBOX_DIR=./01_Library/inbox

# OCR 설정
OCR_ENABLED=true
OCR_LANGUAGES=deu+eng+grc+heb+kor

# 로그 레벨
LOG_LEVEL=INFO
```

### 성능 조정

대용량 PDF 처리 시 Docker 리소스 할당 증가:
- Docker Desktop → Settings → Resources
- Memory: 8GB+ 권장
- CPU: 4+ cores 권장

---

## 🟣 Obsidian 연동 상세 가이드

본 시스템의 검색 결과를 옵시디언 지식 베이스로 통합하는 구체적인 워크플로우(Custom Frames, MCP 서버 등록 등)는 별도의 상세 가이드를 확인하세요.

👉 [Obsidian 연동 가이드 (docs/OBSIDIAN_INTEGRATION.md)](docs/OBSIDIAN_INTEGRATION.md)

---

> **Made by [Kerygma Press](https://www.kerygma.co.kr)**
